﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Mvcshopping.Models;
using Mvcshopping.ViewModel;

namespace Mvcshopping.Controllers
{
    public class ItemController : Controller
    {
        // GET: Item
        private edbEntities ed;
        public ItemController()
        {
            ed = new edbEntities();

        }
        public ActionResult Index()
        {
            ItemViewModel it = new ItemViewModel();
            it.selectlistitem = (from ob in ed.Categories 
                                 select
            new SelectListItem {
  Text=ob.CategoryName, Value=ob.CategoryId.ToString(),Selected=true
            });

return View(it);
            }
            
        
    }
}